package org.jnius;

public class HelloWorld {
	public String hello() {
		return new String("world");
	}
}
