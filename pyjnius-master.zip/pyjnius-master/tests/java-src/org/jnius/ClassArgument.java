package org.jnius;


public class ClassArgument {
    public static String getName(Class klass) {
        return klass.toString();
    }
}
